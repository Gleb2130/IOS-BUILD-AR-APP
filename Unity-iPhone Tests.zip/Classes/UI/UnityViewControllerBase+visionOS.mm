#if PLATFORM_VISIONOS

#import "UnityViewControllerBase.h"
#import "UnityAppController.h"

@implementation UnityDefaultViewController
@end

#endif // PLATFORM_VISIONOS
