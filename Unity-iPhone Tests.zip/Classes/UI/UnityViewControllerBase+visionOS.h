#pragma once

//for visionos we need just one view controller subclass as there is no screen orientation here
@interface UnityDefaultViewController : UnityViewControllerBase
{
}
@end
