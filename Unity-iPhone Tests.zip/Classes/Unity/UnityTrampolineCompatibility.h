#pragma once

#if !UNITY_TRAMPOLINE_IN_USE
#include "UnityPrefix.h"
#endif
