Frameworks directory is used by Unity to store framework plugins.
In the case where no plugins are available, the directory still needs to exist because Xcode project expects it to be here.
If the Frameworks directory is deleted, it will show up in Xcode as red.